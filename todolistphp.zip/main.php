<?php

$shits = [];

function displayMenu()
{
    echo "\n--- To-Do Shit Menu ---\n";
    echo "1. View Shits\n";
    echo "2. Add Shit\n";
    echo "3. Remove Shit\n";
    echo "4. Exit\n";
    echo "Enter your choice: ";
}

function viewShits($shits)
{
    echo "\nTo-Do Shit\n";
    if (empty($shits)) {
        echo "No shits found.\n";
    } else {
        foreach ($shits as $index => $shit) {
            echo ($index + 1) . ". $shit\n";
        }
    }
}

function addShit(&$shits)
{
    echo "Enter the shit to add: ";
    $shit = trim(fgets(STDIN));
    if (!empty($shit)) {
        $shits[] = $shit;
        echo "Shit added successfully!\n";
    } else {
        echo "Shit cannot be empty.\n";
    }
}

function removeShit(&$shits)
{
    viewShits($shits);
    echo "Enter the shit number to remove: ";
    $shitNumber = trim(fgets(STDIN));

    if (is_numeric($shitNumber) && $shitNumber > 0 && $shitNumber <= count($shits)) {
        $index = $shitNumber - 1;
        array_splice($shits, $index, 1);
        echo "Shit removed successfully!\n";
    } else {
        echo "Invalid shit number.\n";
    }
}

while (true) {
    displayMenu();
    $choice = trim(fgets(STDIN));

    switch ($choice) {
        case 1:
            viewShits($shits);
            break;
        case 2:
            addShit($shits);
            break;
        case 3:
            removeShit($shits);
            break;
        case 4:
            echo "Exiting the To-Do Shit application. Goodbye!\n";
            exit;
        default:
            echo "Invalid choice. Please try again.\n";
    }
}

