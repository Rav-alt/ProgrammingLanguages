#!/usr/bin/perl
use strict;
use warnings;

my @todo_list;

sub display_menu {
    print "\nTo Do Shit\n";
    print "1. Add Shit\n";
    print "2. View List\n";
    print "3. Remove Shit\n";
    print "4. Exit\n";
    print "Enter your choice: ";
}

sub view_todo_list {
    print "\nYour To Do Shit\n";
    if (@todo_list) {
        for my $i (0 .. $#todo_list) {
            print $i + 1, ". ", $todo_list[$i], "\n";  # Removed parentheses
        }
    } else {
        print "Your todo shit is empty!\n";
    }
}

sub add_shit {
    print "\nEnter new shit: ";
    chomp(my $shit = <STDIN>);
    push @todo_list, $shit;
    print "Shit added successfully!\n";
}

sub remove_shit {
    view_todo_list();
    print "\nEnter the shit number to remove: ";
    chomp(my $shit_number = <STDIN>);
    if ($shit_number > 0 && $shit_number <= @todo_list) {
        my $removed_shit = splice(@todo_list, $shit_number - 1, 1);
        print "Shit '", $removed_shit, "' removed successfully!\n"; # Proper concatenation
    } else {
        print "Invalid shit number!\n";
    }
}

# Main program loop
while (1) {
    display_menu();
    chomp(my $choice = <STDIN>);

    if ($choice == 1) {
        add_shit();
    } elsif ($choice == 2) {
        view_todo_list();
    } elsif ($choice == 3) {
        remove_shit();
    } elsif ($choice == 4) {
        print "Exiting the program. Goodbye!\n";
        last;
    } else {
        print "Invalid choice! Please try again.\n";
    }
}


